# 📦 Installation Guide

Step-by-step instructions to get the Chess Game running on your machine.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Step 1 — Install Java (JDK)](#step-1--install-java-jdk)
- [Step 2 — Verify Java Installation](#step-2--verify-java-installation)
- [Step 3 — Clone the Repository](#step-3--clone-the-repository)
- [Step 4 — Compile the Source Code](#step-4--compile-the-source-code)
- [Step 5 — Run the Game](#step-5--run-the-game)
- [Troubleshooting](#troubleshooting)
- [Uninstallation](#uninstallation)

---

## Prerequisites

| Requirement | Details |
|---|---|
| **Java JDK** | Version 11 or higher (17+ recommended) |
| **Git** | For cloning the repository (or download as ZIP) |
| **OS** | Windows 10/11, macOS 10.15+, or Linux (any distro with a desktop environment) |

> **Note:** This is a desktop GUI application. It requires a display/monitor — it will not run in a headless (no-GUI) environment.

---

## Step 1 — Install Java (JDK)

If you don't already have Java installed, follow the instructions for your operating system:

### 🪟 Windows

1. Download the JDK from [Oracle](https://www.oracle.com/java/technologies/downloads/) or [Adoptium (Eclipse Temurin)](https://adoptium.net/).
2. Run the installer and follow the prompts.
3. The installer will automatically add Java to your system `PATH`.

**Alternative (using winget):**
```powershell
winget install EclipseAdoptium.Temurin.21.JDK
```

### 🍎 macOS

**Using Homebrew:**
```bash
brew install openjdk@21
```

After installation, follow the instructions printed by Homebrew to symlink the JDK:
```bash
sudo ln -sfn $(brew --prefix)/opt/openjdk@21/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk-21.jdk
```

### 🐧 Linux (Debian/Ubuntu)

```bash
sudo apt update
sudo apt install openjdk-21-jdk
```

### 🐧 Linux (Fedora)

```bash
sudo dnf install java-21-openjdk-devel
```

### 🐧 Linux (Arch)

```bash
sudo pacman -S jdk-openjdk
```

---

## Step 2 — Verify Java Installation

Open a terminal or command prompt and run:

```bash
java -version
```

You should see output similar to:

```
openjdk version "21.0.2" 2024-01-16
OpenJDK Runtime Environment (build 21.0.2+13)
OpenJDK 64-Bit Server VM (build 21.0.2+13, mixed mode)
```

Also verify the compiler is available:

```bash
javac -version
```

Expected output:

```
javac 21.0.2
```

> ⚠️ If `javac` is not found but `java` works, you may have installed the JRE instead of the JDK. You need the **JDK** (Java Development Kit) to compile the source code.

---

## Step 3 — Clone the Repository

```bash
git clone https://github.com/<your-username>/2-Player-Chess-Java--Swing-.git
cd 2-Player-Chess-Java--Swing-
```

**Don't have Git?** You can also download the repository as a ZIP file from the GitHub page and extract it.

---

## Step 4 — Compile the Source Code

From the **root project directory** (`ChessGame/`), run:

### Windows (Command Prompt)

```cmd
javac -encoding UTF-8 -d out src\chess\*.java
```

### Windows (PowerShell)

```powershell
javac -encoding UTF-8 -d out src/chess/*.java
```

### macOS / Linux

```bash
javac -encoding UTF-8 -d out src/chess/*.java
```

**What this does:**

| Flag | Purpose |
|---|---|
| `-encoding UTF-8` | Ensures the compiler correctly reads Unicode chess piece characters (♔ ♕ ♖ etc.) in the source files |
| `-d out` | Places compiled `.class` files into the `out/` directory |
| `src/chess/*.java` | Compiles all Java source files in the `src/chess/` package |

> ✅ If the command completes with **no output**, the compilation was successful.

---

## Step 5 — Run the Game

After compilation, start the game with:

```bash
java -cp out chess.Main
```

The chess board window should open **maximized** and ready to play!

**Alternative entry point:**
```bash
java -cp out chess.ChessGUI
```

Both commands are equivalent — `Main.java` and `ChessGUI.java` each contain a `main()` method.

---

## Troubleshooting

### ❌ `javac` is not recognized / command not found

**Cause:** Java JDK is not installed or not added to your system `PATH`.

**Fix:**
1. Verify JDK is installed: look for a directory like `C:\Program Files\Java\jdk-21` (Windows) or `/usr/lib/jvm/java-21-openjdk` (Linux).
2. Add the JDK `bin` directory to your `PATH` environment variable.
3. Restart your terminal after making changes.

### ❌ `error: unmappable character for encoding ...`

**Cause:** Missing the `-encoding UTF-8` flag during compilation.

**Fix:** Make sure you include `-encoding UTF-8` in the `javac` command:
```bash
javac -encoding UTF-8 -d out src/chess/*.java
```

### ❌ `Error: Could not find or load main class chess.Main`

**Cause:** The `out/` directory doesn't contain the compiled classes, or you're running the command from the wrong directory.

**Fix:**
1. Make sure you compiled first (`javac` step).
2. Make sure you're running the `java` command from the **project root** (`ChessGame/`), not from inside `src/` or `out/`.
3. Verify that `out/chess/Main.class` exists.

### ❌ Chess piece symbols appear as boxes or `?` characters

**Cause:** Your system doesn't have a font that supports Unicode chess piece characters.

**Fix:**
- **Windows:** Install or ensure "Segoe UI Symbol" or "Segoe UI Emoji" font is available.
- **Linux:** Install a Unicode font: `sudo apt install fonts-noto`
- **macOS:** The default system fonts should work. If not, install [Noto](https://fonts.google.com/noto).

### ❌ The window is blank or doesn't appear

**Cause:** Running in a headless environment (SSH, WSL without GUI, Docker without display).

**Fix:** This is a GUI application — run it on a machine with a display. If using WSL, install an X server like [VcXsrv](https://sourceforge.net/projects/vcxsrv/) or use WSLg (Windows 11).

---

## Uninstallation

This project has **no system-level installation** — it runs entirely from the project directory.

To remove it, simply delete the `ChessGame/` folder:

```bash
# From the parent directory
rm -rf ChessGame      # macOS / Linux
rmdir /s /q ChessGame # Windows (Command Prompt)
```

---

## Quick Reference

| Action | Command |
|---|---|
| Compile | `javac -encoding UTF-8 -d out src/chess/*.java` |
| Run | `java -cp out chess.Main` |
| Clean build | Delete the `out/` folder and recompile |

---

*Happy playing! ♟️*

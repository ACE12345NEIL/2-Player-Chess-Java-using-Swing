package chess;

public class Knight extends Piece {
    public Knight(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♘" : "♞");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        Piece target = board.getPiece(r, c);
        if (target != null && target.isWhite() == this.isWhite()) return false;

        int dr = Math.abs(r - row);
        int dc = Math.abs(c - col);
        return (dr == 2 && dc == 1) || (dr == 1 && dc == 2);
    }
}
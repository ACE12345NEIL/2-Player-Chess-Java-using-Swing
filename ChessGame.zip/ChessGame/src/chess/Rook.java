package chess;

public class Rook extends Piece {
    private boolean hasMoved = false;

    public Rook(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♖" : "♜");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        Piece target = board.getPiece(r, c);
        if (target != null && target.isWhite() == this.isWhite()) return false;

        if (row == r || col == c) { // horizontal or vertical
            return board.isPathClear(row, col, r, c, this);
        }
        return false;
    }

    @Override
    public void moveTo(int r, int c) {
        hasMoved = true;
        super.moveTo(r, c);
    }

    public boolean hasMoved() {
        return hasMoved;
    }
}
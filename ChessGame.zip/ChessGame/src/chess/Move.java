package chess;

public class Move {
    public int sr, sc, er, ec;

    public Move(int sr, int sc, int er, int ec) {
        this.sr = sr;
        this.sc = sc;
        this.er = er;
        this.ec = ec;
    }
}
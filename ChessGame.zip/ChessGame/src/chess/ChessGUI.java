package chess;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class ChessGUI {

    private JFrame frame;
    private JButton[][] buttons = new JButton[8][8];
    private ChessGame game = new ChessGame();

    private int selR = -1, selC = -1;

    // ═══════════════════════════════════════
    //  ANCIENT THEME — Color Palette
    // ═══════════════════════════════════════
    private static final Color BOARD_LIGHT    = new Color(222, 200, 162);   // Parchment
    private static final Color BOARD_DARK     = new Color(150, 100, 50);    // Walnut
    private static final Color BG_DARKEST     = new Color(30, 20, 12);      // Ebony
    private static final Color BG_DARK        = new Color(42, 28, 16);      // Dark oak
    private static final Color BG_MEDIUM      = new Color(58, 40, 24);      // Medium wood
    private static final Color PANEL_BG       = new Color(48, 33, 20);      // Panel wood
    private static final Color ACCENT_GOLD    = new Color(212, 175, 55);    // Royal gold
    private static final Color ACCENT_BRONZE  = new Color(185, 148, 80);    // Warm bronze
    private static final Color TEXT_LIGHT      = new Color(235, 220, 195);   // Ivory
    private static final Color TEXT_GOLD       = new Color(218, 195, 140);   // Gold ink
    private static final Color TEXT_DIM        = new Color(150, 130, 100);   // Faded ink
    private static final Color SELECT_COLOR   = new Color(110, 148, 68);    // Sage selection
    private static final Color LEGAL_LIGHT    = new Color(215, 195, 115);   // Gold on light
    private static final Color LEGAL_DARK     = new Color(170, 148, 68);    // Gold on dark
    private static final Color CHECK_RED      = new Color(172, 42, 42);     // Crimson
    private static final Color BORDER_GOLD    = new Color(140, 110, 50);    // Warm border
    private static final Color ACTIVE_BG      = new Color(65, 50, 30);      // Active timer bg
    private static final Color INACTIVE_BG    = new Color(38, 26, 14);      // Inactive timer bg

    // ═══ Captured Pieces ═══
    private JPanel capturedPanel;
    private JPanel capturedWhitePanel;
    private JPanel capturedBlackPanel;
    private List<Piece> capturedWhite = new ArrayList<>();
    private List<Piece> capturedBlack = new ArrayList<>();

    // ═══ Move History ═══
    private DefaultListModel<String> moveHistoryModel = new DefaultListModel<>();
    private JList<String> moveHistoryList;

    // ═══ Turn Indicator ═══
    private JLabel turnLabel;
    private JPanel turnPanel;

    // ═══ Chess Timer ═══
    private int initialTimeSeconds;
    private int whiteTimeSeconds;
    private int blackTimeSeconds;
    private boolean timerEnabled;
    private JLabel whiteTimerLabel;
    private JLabel blackTimerLabel;
    private JPanel whiteTimerPanel;
    private JPanel blackTimerPanel;
    private Timer clockTimer;
    private boolean gameOver = false;

    // ═══ Fonts ═══
    private static final Font FONT_TITLE      = new Font("Serif", Font.BOLD, 20);
    private static final Font FONT_BODY       = new Font("Serif", Font.PLAIN, 15);
    private static final Font FONT_TIMER      = new Font("Serif", Font.BOLD, 34);
    private static final Font FONT_LABEL      = new Font("Serif", Font.BOLD, 14);
    private static final Font FONT_SECTION    = new Font("Serif", Font.BOLD, 11);
    private static final Font FONT_BOARD_LBL  = new Font("Serif", Font.BOLD, 16);
    private static final Font FONT_BTN        = new Font("Serif", Font.BOLD, 13);

    // ════════════════════════════════════════
    //  CONSTRUCTOR
    // ════════════════════════════════════════
    public ChessGUI() {
        int selectedTime = showTimeControlDialog();
        if (selectedTime == Integer.MIN_VALUE) {
            System.exit(0);
            return;
        }

        timerEnabled = (selectedTime > 0);
        initialTimeSeconds = selectedTime;
        whiteTimeSeconds = selectedTime;
        blackTimeSeconds = selectedTime;

        buildUI();
        refreshBoard();
        highlightCheck();
        updateTurnIndicator();
        if (timerEnabled) {
            updateTimerHighlight();
            startClock();
        }
    }

    // ════════════════════════════════════════
    //  TIME CONTROL — Startup Dialog
    // ════════════════════════════════════════
    private int showTimeControlDialog() {
        final int[] result = { Integer.MIN_VALUE };

        JDialog dialog = new JDialog((JFrame) null, "Time Control", true);
        dialog.setUndecorated(true);
        dialog.setSize(440, 420);
        dialog.setLocationRelativeTo(null);

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBackground(BG_DARKEST);
        main.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ACCENT_GOLD, 2),
            BorderFactory.createEmptyBorder(28, 40, 28, 40)
        ));

        // Ornamental header
        JLabel ornament = new JLabel("⚔  ♔  ♚  ⚔", SwingConstants.CENTER);
        ornament.setFont(new Font("Serif", Font.PLAIN, 26));
        ornament.setForeground(ACCENT_GOLD);
        ornament.setAlignmentX(Component.CENTER_ALIGNMENT);
        main.add(ornament);
        main.add(Box.createRigidArea(new Dimension(0, 6)));

        JLabel title = new JLabel("SELECT TIME CONTROL");
        title.setFont(FONT_TITLE);
        title.setForeground(ACCENT_GOLD);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        main.add(title);

        main.add(Box.createRigidArea(new Dimension(0, 4)));

        JLabel subtitle = new JLabel("Choose the allotted time for each player");
        subtitle.setFont(new Font("Serif", Font.ITALIC, 13));
        subtitle.setForeground(TEXT_DIM);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        main.add(subtitle);

        main.add(Box.createRigidArea(new Dimension(0, 22)));

        // Time options
        String[][] options = {
            { "∞",     "No Limit",   "0"   },
            { "1:00",  "1 Minute",   "60"  },
            { "3:00",  "3 Minutes",  "180" },
            { "5:00",  "5 Minutes",  "300" },
            { "10:00", "10 Minutes", "600" },
        };

        for (String[] opt : options) {
            JButton btn = new JButton(opt[0] + "   ─   " + opt[1]);
            btn.setFont(FONT_LABEL);
            btn.setForeground(TEXT_LIGHT);
            btn.setBackground(BG_MEDIUM);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GOLD, 1),
                BorderFactory.createEmptyBorder(11, 20, 11, 20)
            ));
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(320, 48));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

            int timeVal = Integer.parseInt(opt[2]);
            btn.addActionListener(e -> { result[0] = timeVal; dialog.dispose(); });

            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btn.setBackground(ACCENT_BRONZE);
                    btn.setForeground(BG_DARKEST);
                }
                public void mouseExited(MouseEvent e) {
                    btn.setBackground(BG_MEDIUM);
                    btn.setForeground(TEXT_LIGHT);
                }
            });

            main.add(btn);
            main.add(Box.createRigidArea(new Dimension(0, 7)));
        }

        dialog.add(main);
        dialog.setVisible(true);
        return result[0];
    }

    // ════════════════════════════════════════
    //  BUILD UI
    // ════════════════════════════════════════
    private void buildUI() {
        frame = new JFrame("♔ CHESS ♚");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(BG_DARKEST);

        // ─── Board Wrapper ───
        JPanel boardWrapper = new JPanel(new BorderLayout());
        boardWrapper.setBackground(BG_DARKEST);
        boardWrapper.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 4));

        JPanel boardOuter = new JPanel(new BorderLayout());
        boardOuter.setBackground(BG_DARK);
        boardOuter.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ACCENT_GOLD, 2),
            BorderFactory.createLineBorder(BORDER_GOLD, 3)
        ));

        JPanel boardPanel = new JPanel(new GridLayout(9, 9, 0, 0));
        boardPanel.setBackground(BG_DARK);

        Font chessFont = new Font("Segoe UI Symbol", Font.PLAIN, 50);
        if (!chessFont.canDisplay('\u2659')) chessFont = new Font("Segoe UI Emoji", Font.PLAIN, 50);

        // Top-left corner
        JLabel corner = new JLabel("", SwingConstants.CENTER);
        corner.setOpaque(true);
        corner.setBackground(BG_DARK);
        boardPanel.add(corner);

        // Column headers A–H
        for (char c = 'A'; c <= 'H'; c++) {
            JLabel lbl = new JLabel(String.valueOf(c), SwingConstants.CENTER);
            lbl.setFont(FONT_BOARD_LBL);
            lbl.setForeground(ACCENT_GOLD);
            lbl.setOpaque(true);
            lbl.setBackground(BG_DARK);
            boardPanel.add(lbl);
        }

        // Board rows
        for (int r = 0; r < 8; r++) {
            JLabel rowLbl = new JLabel(String.valueOf(8 - r), SwingConstants.CENTER);
            rowLbl.setFont(FONT_BOARD_LBL);
            rowLbl.setForeground(ACCENT_GOLD);
            rowLbl.setOpaque(true);
            rowLbl.setBackground(BG_DARK);
            boardPanel.add(rowLbl);

            for (int c = 0; c < 8; c++) {
                JButton b = new JButton();
                b.setFont(chessFont);
                b.setHorizontalAlignment(SwingConstants.CENTER);
                b.setVerticalAlignment(SwingConstants.CENTER);
                b.setMargin(new Insets(0, 0, 0, 0));
                b.setFocusPainted(false);
                b.setOpaque(true);
                b.setBorderPainted(true);
                b.setBorder(BorderFactory.createLineBorder(new Color(70, 48, 25, 80), 1));
                b.setBackground((r + c) % 2 == 0 ? BOARD_LIGHT : BOARD_DARK);
                b.setCursor(new Cursor(Cursor.HAND_CURSOR));

                int rr = r, cc = c;
                b.addActionListener(e -> handleClick(rr, cc));

                buttons[r][c] = b;
                boardPanel.add(b);
            }
        }

        boardOuter.add(boardPanel, BorderLayout.CENTER);
        boardWrapper.add(boardOuter, BorderLayout.CENTER);

        // ─── Right Panel (sidebar) ───
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(BG_DARKEST);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(12, 8, 12, 12));
        rightPanel.setPreferredSize(new Dimension(290, 0));

        // ── Turn Indicator ──
        turnPanel = makeSectionPanel("⚔ CURRENT TURN ⚔");
        turnLabel = new JLabel("♔  WHITE's TURN", SwingConstants.CENTER);
        turnLabel.setFont(FONT_TITLE);
        turnLabel.setForeground(ACCENT_GOLD);
        turnLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        turnPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        turnPanel.add(turnLabel);
        turnPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        rightPanel.add(turnPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        // ── Timer Panels ──
        if (timerEnabled) {
            whiteTimerPanel = makeTimerPanel("♔  WHITE", true);
            rightPanel.add(whiteTimerPanel);
            rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));

            blackTimerPanel = makeTimerPanel("♚  BLACK", false);
            rightPanel.add(blackTimerPanel);
            rightPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        // ── Move History ──
        JPanel historyPanel = makeSectionPanel("📜 MOVE HISTORY");
        moveHistoryList = new JList<>(moveHistoryModel);
        moveHistoryList.setBackground(BG_DARK);
        moveHistoryList.setForeground(TEXT_LIGHT);
        moveHistoryList.setFont(FONT_BODY);
        moveHistoryList.setSelectionBackground(ACCENT_BRONZE);
        moveHistoryList.setSelectionForeground(BG_DARKEST);
        moveHistoryList.setFixedCellHeight(26);

        JScrollPane scrollPane = new JScrollPane(moveHistoryList);
        scrollPane.setPreferredSize(new Dimension(250, timerEnabled ? 160 : 260));
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_GOLD, 1));
        scrollPane.getViewport().setBackground(BG_DARK);
        historyPanel.add(scrollPane);
        historyPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        rightPanel.add(historyPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        // ── Captured Pieces ──
        capturedPanel = makeSectionPanel("⚰ CAPTURED PIECES");

        capturedWhitePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        capturedWhitePanel.setOpaque(false);
        JLabel wLbl = new JLabel("White: ");
        wLbl.setFont(new Font("Georgia", Font.ITALIC, 13));
        wLbl.setForeground(TEXT_DIM);
        capturedWhitePanel.add(wLbl);

        capturedBlackPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        capturedBlackPanel.setOpaque(false);
        JLabel bLbl = new JLabel("Black: ");
        bLbl.setFont(new Font("Georgia", Font.ITALIC, 13));
        bLbl.setForeground(TEXT_DIM);
        capturedBlackPanel.add(bLbl);

        capturedPanel.add(capturedWhitePanel);
        capturedPanel.add(capturedBlackPanel);
        capturedPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        rightPanel.add(capturedPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // ── Action Buttons ──
        JPanel btnRow = new JPanel(new GridLayout(1, 2, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setMaximumSize(new Dimension(270, 42));

        JButton resetBtn = makeStyledButton("↺  Reset");
        resetBtn.addActionListener(e -> resetBoard());
        btnRow.add(resetBtn);

        JButton newBtn = makeStyledButton("♔  New Game");
        newBtn.addActionListener(e -> newGame());
        btnRow.add(newBtn);

        rightPanel.add(btnRow);

        // ─── Assembly ───
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, boardWrapper, rightPanel);
        split.setResizeWeight(0.73);
        split.setDividerSize(3);
        split.setBorder(null);
        split.setBackground(BG_DARKEST);
        frame.add(split);

        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
    }

    // ════════════════════════════════════════
    //  REUSABLE STYLED COMPONENTS
    // ════════════════════════════════════════
    private JPanel makeSectionPanel(String title) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(PANEL_BG);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_GOLD, 1),
            BorderFactory.createEmptyBorder(7, 12, 7, 12)
        ));

        JLabel lbl = new JLabel("━━  " + title + "  ━━");
        lbl.setFont(FONT_SECTION);
        lbl.setForeground(TEXT_GOLD);
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(lbl);
        return p;
    }

    private JPanel makeTimerPanel(String playerName, boolean white) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(INACTIVE_BG);
        p.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_GOLD, 1),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)
        ));

        JLabel name = new JLabel(playerName, SwingConstants.CENTER);
        name.setFont(FONT_LABEL);
        name.setForeground(white ? TEXT_LIGHT : TEXT_DIM);
        name.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(name);

        JLabel time = new JLabel(formatTime(initialTimeSeconds), SwingConstants.CENTER);
        time.setFont(FONT_TIMER);
        time.setForeground(ACCENT_GOLD);
        time.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(time);

        if (white) whiteTimerLabel = time;
        else       blackTimerLabel = time;

        return p;
    }

    private JButton makeStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(TEXT_LIGHT);
        btn.setBackground(BG_MEDIUM);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_GOLD, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(ACCENT_BRONZE);
                btn.setForeground(BG_DARKEST);
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(BG_MEDIUM);
                btn.setForeground(TEXT_LIGHT);
            }
        });
        return btn;
    }

    // ════════════════════════════════════════
    //  CLICK HANDLING
    // ════════════════════════════════════════
    private void handleClick(int r, int c) {
        if (gameOver) return;

        Board board = game.getBoard();
        Piece clickedPiece = board.getPiece(r, c);

        // Nothing selected yet → try to select a piece
        if (selR == -1) {
            if (clickedPiece != null && clickedPiece.isWhite() == game.isWhiteTurn()) {
                selR = r;
                selC = c;
                buttons[r][c].setBackground(SELECT_COLOR);
                highlightLegalMoves(r, c);
            }
            return;
        }

        // Already selected → attempt move
        int fromR = selR, fromC = selC;
        Piece movingPiece = board.getPiece(fromR, fromC);

        clearHighlights();

        if (movingPiece != null && movingPiece.isValidMove(r, c, board)) {
            Piece targetPiece = board.getPiece(r, c);

            animateMove(fromR, fromC, r, c, movingPiece, () -> {
                try {
                    game.makeMove(new Move(fromR, fromC, r, c));

                    if (targetPiece != null) {
                        if (targetPiece.isWhite()) capturedWhite.add(targetPiece);
                        else                       capturedBlack.add(targetPiece);
                    }

                    // Algebraic-style notation  e.g. ♙ E2 → E4
                    String notation = movingPiece.getIcon() + "  " +
                        (char) ('A' + fromC) + (8 - fromR) +
                        " → " +
                        (char) ('A' + c) + (8 - r);
                    moveHistoryModel.addElement(notation);
                    moveHistoryList.ensureIndexIsVisible(moveHistoryModel.size() - 1);

                    updateCapturedPieces();

                    // Check if the game ended (checkmate / stalemate)
                    if (game.isGameOver()) {
                        gameOver = true;
                        if (clockTimer != null) clockTimer.stop();
                    }

                } catch (Exception ex) {
                    showThemedMessage(ex.getMessage());
                }

                selR = selC = -1;
                refreshBoard();
                highlightCheck();
                updateTurnIndicator();
                if (timerEnabled) updateTimerHighlight();
            });
        } else {
            // Invalid target — re-select if clicking own piece, else deselect
            if (clickedPiece != null && clickedPiece.isWhite() == game.isWhiteTurn()) {
                selR = r;
                selC = c;
                buttons[r][c].setBackground(SELECT_COLOR);
                highlightLegalMoves(r, c);
            } else {
                selR = selC = -1;
                refreshBoard();
                highlightCheck();
            }
        }
    }

    // ════════════════════════════════════════
    //  HIGHLIGHT LEGAL MOVES
    // ════════════════════════════════════════
    private void highlightLegalMoves(int r, int c) {
        Board board = game.getBoard();
        Piece piece = board.getPiece(r, c);
        if (piece == null) return;

        for (int rr = 0; rr < 8; rr++)
            for (int cc = 0; cc < 8; cc++)
                if (piece.isValidMove(rr, cc, board))
                    buttons[rr][cc].setBackground((rr + cc) % 2 == 0 ? LEGAL_LIGHT : LEGAL_DARK);

        buttons[r][c].setBackground(SELECT_COLOR);
    }

    private void clearHighlights() {
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++)
                buttons[r][c].setBackground((r + c) % 2 == 0 ? BOARD_LIGHT : BOARD_DARK);
    }

    // ════════════════════════════════════════
    //  TURN INDICATOR
    // ════════════════════════════════════════
    private void updateTurnIndicator() {
        if (gameOver) {
            turnLabel.setText("⚔  GAME OVER  ⚔");
            turnPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(CHECK_RED, 2),
                BorderFactory.createEmptyBorder(6, 11, 6, 11)
            ));
        } else if (game.isWhiteTurn()) {
            turnLabel.setText("♔  WHITE's TURN");
            turnPanel.setBackground(new Color(58, 50, 35));
            turnPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_GOLD, 2),
                BorderFactory.createEmptyBorder(6, 11, 6, 11)
            ));
        } else {
            turnLabel.setText("♚  BLACK's TURN");
            turnPanel.setBackground(new Color(35, 30, 25));
            turnPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_BRONZE, 2),
                BorderFactory.createEmptyBorder(6, 11, 6, 11)
            ));
        }
    }

    // ════════════════════════════════════════
    //  CHESS TIMER
    // ════════════════════════════════════════
    private void startClock() {
        clockTimer = new Timer(1000, e -> {
            if (gameOver) return;

            if (game.isWhiteTurn()) {
                whiteTimeSeconds--;
                whiteTimerLabel.setText(formatTime(whiteTimeSeconds));
                if (whiteTimeSeconds <= 10) whiteTimerLabel.setForeground(CHECK_RED);
                if (whiteTimeSeconds <= 0) {
                    gameOver = true;
                    clockTimer.stop();
                    showThemedMessage("⏳ Time's up! Black wins!");
                }
            } else {
                blackTimeSeconds--;
                blackTimerLabel.setText(formatTime(blackTimeSeconds));
                if (blackTimeSeconds <= 10) blackTimerLabel.setForeground(CHECK_RED);
                if (blackTimeSeconds <= 0) {
                    gameOver = true;
                    clockTimer.stop();
                    showThemedMessage("⏳ Time's up! White wins!");
                }
            }
        });
        clockTimer.start();
    }

    private void updateTimerHighlight() {
        if (!timerEnabled) return;

        if (game.isWhiteTurn()) {
            whiteTimerPanel.setBackground(ACTIVE_BG);
            whiteTimerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_GOLD, 2),
                BorderFactory.createEmptyBorder(5, 13, 5, 13)
            ));
            blackTimerPanel.setBackground(INACTIVE_BG);
            blackTimerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GOLD, 1),
                BorderFactory.createEmptyBorder(6, 14, 6, 14)
            ));
        } else {
            blackTimerPanel.setBackground(ACTIVE_BG);
            blackTimerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(ACCENT_GOLD, 2),
                BorderFactory.createEmptyBorder(5, 13, 5, 13)
            ));
            whiteTimerPanel.setBackground(INACTIVE_BG);
            whiteTimerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_GOLD, 1),
                BorderFactory.createEmptyBorder(6, 14, 6, 14)
            ));
        }
    }

    private String formatTime(int totalSeconds) {
        if (totalSeconds < 0) totalSeconds = 0;
        return String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
    }

    // ════════════════════════════════════════
    //  THEMED DIALOG
    // ════════════════════════════════════════
    private void showThemedMessage(String msg) {
        JDialog dialog = new JDialog(frame, "Chess", true);
        dialog.setUndecorated(true);
        dialog.setSize(380, 160);
        dialog.setLocationRelativeTo(frame);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(BG_DARKEST);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ACCENT_GOLD, 2),
            BorderFactory.createEmptyBorder(22, 28, 22, 28)
        ));

        JLabel lbl = new JLabel(msg, SwingConstants.CENTER);
        lbl.setFont(FONT_TITLE);
        lbl.setForeground(ACCENT_GOLD);
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(lbl);
        panel.add(Box.createRigidArea(new Dimension(0, 18)));

        JButton ok = makeStyledButton("OK");
        ok.setAlignmentX(Component.CENTER_ALIGNMENT);
        ok.setMaximumSize(new Dimension(120, 38));
        ok.addActionListener(e -> dialog.dispose());
        panel.add(ok);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    // ════════════════════════════════════════
    //  PIECE ANIMATION
    // ════════════════════════════════════════
    private void animateMove(int sr, int sc, int er, int ec, Piece piece, Runnable onComplete) {
        JLayeredPane layeredPane = frame.getLayeredPane();
        JLabel movingLabel = new JLabel(piece.getIcon(), SwingConstants.CENTER);
        movingLabel.setFont(buttons[sr][sc].getFont());

        Point start = SwingUtilities.convertPoint(
            buttons[sr][sc].getParent(), buttons[sr][sc].getLocation(), layeredPane);
        Point end = SwingUtilities.convertPoint(
            buttons[er][ec].getParent(), buttons[er][ec].getLocation(), layeredPane);

        movingLabel.setBounds(start.x, start.y, 80, 80);
        layeredPane.add(movingLabel, JLayeredPane.PALETTE_LAYER);
        buttons[sr][sc].setText("");

        int totalFrames = 20;
        Timer anim = new Timer(18, null);
        final int[] step = {0};

        anim.addActionListener(e -> {
            step[0]++;
            float t = (float) step[0] / totalFrames;
            int x = start.x + Math.round((end.x - start.x) * t);
            int y = start.y + Math.round((end.y - start.y) * t
                    - 12f * (float) Math.sin(t * Math.PI));
            movingLabel.setLocation(x, y);

            if (step[0] >= totalFrames) {
                anim.stop();
                layeredPane.remove(movingLabel);
                layeredPane.repaint();
                onComplete.run();
            }
        });
        anim.start();
    }

    // ════════════════════════════════════════
    //  CAPTURED PIECES
    // ════════════════════════════════════════
    private void updateCapturedPieces() {
        // Rebuild white captured
        capturedWhitePanel.removeAll();
        JLabel wLbl = new JLabel("White: ");
        wLbl.setFont(new Font("Georgia", Font.ITALIC, 13));
        wLbl.setForeground(TEXT_DIM);
        capturedWhitePanel.add(wLbl);
        Font capFont = new Font("Segoe UI Symbol", Font.PLAIN, 26);
        for (Piece p : capturedWhite) {
            JLabel l = new JLabel(p.getIcon());
            l.setFont(capFont);
            l.setForeground(TEXT_LIGHT);
            capturedWhitePanel.add(l);
        }

        // Rebuild black captured
        capturedBlackPanel.removeAll();
        JLabel bLbl = new JLabel("Black: ");
        bLbl.setFont(new Font("Georgia", Font.ITALIC, 13));
        bLbl.setForeground(TEXT_DIM);
        capturedBlackPanel.add(bLbl);
        for (Piece p : capturedBlack) {
            JLabel l = new JLabel(p.getIcon());
            l.setFont(capFont);
            l.setForeground(TEXT_LIGHT);
            capturedBlackPanel.add(l);
        }

        capturedWhitePanel.revalidate(); capturedWhitePanel.repaint();
        capturedBlackPanel.revalidate(); capturedBlackPanel.repaint();
    }

    // ════════════════════════════════════════
    //  BOARD REFRESH / UTILS
    // ════════════════════════════════════════
    private void refreshBoard() {
        Board board = game.getBoard();
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                Piece p = board.getPiece(r, c);
                buttons[r][c].setText(p == null ? "" : p.getIcon());
            }
    }

    private void highlightCheck() {
        Piece king = game.getKingInCheck();
        if (king != null)
            buttons[king.getRow()][king.getCol()].setBackground(CHECK_RED);
    }

    private void resetBoard() {
        game = new ChessGame();
        selR = selC = -1;
        gameOver = false;
        capturedWhite.clear();
        capturedBlack.clear();
        moveHistoryModel.clear();

        if (timerEnabled) {
            if (clockTimer != null) clockTimer.stop();
            whiteTimeSeconds = initialTimeSeconds;
            blackTimeSeconds = initialTimeSeconds;
            whiteTimerLabel.setText(formatTime(whiteTimeSeconds));
            blackTimerLabel.setText(formatTime(blackTimeSeconds));
            whiteTimerLabel.setForeground(ACCENT_GOLD);
            blackTimerLabel.setForeground(ACCENT_GOLD);
            startClock();
        }

        updateCapturedPieces();
        clearHighlights();
        refreshBoard();
        highlightCheck();
        updateTurnIndicator();
        if (timerEnabled) updateTimerHighlight();
    }

    private void newGame() {
        if (clockTimer != null) clockTimer.stop();
        frame.dispose();
        SwingUtilities.invokeLater(ChessGUI::new);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChessGUI::new);
    }
}
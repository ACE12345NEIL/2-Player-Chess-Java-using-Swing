package chess;

import javax.swing.*;
import java.awt.*;

public class ChessGame {

    private Board board = new Board();
    private boolean whiteTurn = true;
    private boolean gameOver = false;

    // Ancient theme colors for dialogs
    private static final Color DLG_BG      = new Color(30, 20, 12);
    private static final Color DLG_GOLD    = new Color(212, 175, 55);
    private static final Color DLG_BRONZE  = new Color(185, 148, 80);
    private static final Color DLG_TEXT    = new Color(235, 220, 195);
    private static final Color DLG_PANEL   = new Color(58, 40, 24);
    private static final Color DLG_BORDER  = new Color(140, 110, 50);

    public Board getBoard() { return board; }

    public void makeMove(Move m) throws InvalidMoveException {
        Piece piece = board.getPiece(m.sr, m.sc);

        if (piece == null) throw new InvalidMoveException("No piece selected.");
        if (piece.isWhite() != whiteTurn) throw new InvalidMoveException("Not your turn.");
        if (!piece.isValidMove(m.er, m.ec, board)) throw new InvalidMoveException("Invalid move.");

        // Castling
        if (piece instanceof King && Math.abs(m.ec - m.sc) == 2) {
            int rookCol = (m.ec > m.sc) ? 7 : 0;
            int newRookCol = (m.sc + m.ec) / 2;
            Piece rook = board.getPiece(m.sr, rookCol);
            if (rook instanceof Rook) board.movePiece(m.sr, rookCol, m.sr, newRookCol);
        }

        // En passant capture
        if (piece instanceof Pawn) {
            Pawn p = (Pawn) piece;
            if (Math.abs(m.ec - m.sc) == 1 && board.isEmpty(m.er, m.ec)) {
                Piece adjacent = board.getPiece(m.sr, m.ec);
                if (adjacent instanceof Pawn && adjacent.isWhite() != p.isWhite() && ((Pawn) adjacent).hasJustDoubleStepped()) {
                    board.removePiece(m.sr, m.ec);
                }
            }
        }

        // Check legality
        Board tempBoard = board.copy();
        tempBoard.movePiece(m.sr, m.sc, m.er, m.ec);
        if (isInCheck(tempBoard, whiteTurn)) throw new InvalidMoveException("Illegal move: king in check.");

        // Execute move
        board.movePiece(m.sr, m.sc, m.er, m.ec);

        // Pawn promotion
        Piece moved = board.getPiece(m.er, m.ec);
        if (moved instanceof Pawn && ((moved.isWhite() && m.er == 0) || (!moved.isWhite() && m.er == 7))) {
            promotePawn(m.er, m.ec);
        }

        // Reset en passant flags
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                Piece p2 = board.getPiece(r, c);
                if (p2 instanceof Pawn && p2 != moved) ((Pawn) p2).resetEnPassant();
            }

        if (moved instanceof Pawn) ((Pawn) moved).setDoubleStep(Math.abs(m.er - m.sr) == 2);

        // Checkmate / Stalemate
        boolean nextCheck = isInCheck(board, !whiteTurn);
        boolean nextHasMoves = hasAnyValidMoves(!whiteTurn);

        if (!nextHasMoves) {
            gameOver = true;
            if (nextCheck) showCustomDialog("♔ Checkmate! " + (whiteTurn ? "White" : "Black") + " wins!");
            else showCustomDialog("Stalemate! The game is a draw.");
        }

        whiteTurn = !whiteTurn;
    }

    private void promotePawn(int r, int c) {
        Piece pawn = board.getPiece(r, c);
        boolean isWhite = pawn.isWhite();

        JDialog dialog = new JDialog((JFrame) null, "Pawn Promotion", true);
        dialog.setUndecorated(true);
        dialog.setSize(420, 160);
        dialog.setLocationRelativeTo(null);

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBackground(DLG_BG);
        main.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(DLG_GOLD, 2),
            BorderFactory.createEmptyBorder(16, 24, 16, 24)
        ));

        JLabel title = new JLabel("♔ Choose Promotion Piece", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 16));
        title.setForeground(DLG_GOLD);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        main.add(title);
        main.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel row = new JPanel(new GridLayout(1, 4, 10, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(380, 70));

        Font pieceFont = new Font("Segoe UI Symbol", Font.PLAIN, 38);
        String[] icons = isWhite
            ? new String[]{"♕", "♖", "♗", "♘"}
            : new String[]{"♛", "♜", "♝", "♞"};
        Piece[] pieces = {
            new Queen(isWhite, r, c), new Rook(isWhite, r, c),
            new Bishop(isWhite, r, c), new Knight(isWhite, r, c)
        };

        for (int i = 0; i < 4; i++) {
            JButton btn = new JButton(icons[i]);
            btn.setFont(pieceFont);
            btn.setForeground(DLG_TEXT);
            btn.setBackground(DLG_PANEL);
            btn.setFocusPainted(false);
            btn.setBorder(BorderFactory.createLineBorder(DLG_BORDER, 1));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            final Piece chosen = pieces[i];
            btn.addActionListener(e -> {
                board.setPiece(r, c, chosen);
                dialog.dispose();
            });
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent e) { btn.setBackground(DLG_BRONZE); }
                public void mouseExited(java.awt.event.MouseEvent e)  { btn.setBackground(DLG_PANEL); }
            });
            row.add(btn);
        }

        main.add(row);
        dialog.add(main);
        dialog.setVisible(true);
    }

    private void showCustomDialog(String msg) {
        JDialog dialog = new JDialog((JFrame) null, "Game Over", true);
        dialog.setUndecorated(true);
        dialog.setSize(400, 170);
        dialog.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(DLG_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(DLG_GOLD, 2),
            BorderFactory.createEmptyBorder(22, 28, 22, 28)
        ));

        JLabel label = new JLabel(msg, SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.BOLD, 18));
        label.setForeground(DLG_GOLD);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(0, 18)));

        JButton okBtn = new JButton("OK");
        okBtn.setFont(new Font("Serif", Font.BOLD, 13));
        okBtn.setForeground(DLG_TEXT);
        okBtn.setBackground(DLG_PANEL);
        okBtn.setFocusPainted(false);
        okBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(DLG_BORDER, 1),
            BorderFactory.createEmptyBorder(8, 30, 8, 30)
        ));
        okBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        okBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        okBtn.addActionListener(e -> dialog.dispose());
        panel.add(okBtn);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private boolean isInCheck(Board b, boolean white) {
        Piece king = null;
        for(int r=0;r<8;r++) for(int c=0;c<8;c++){
            Piece p = b.getPiece(r,c);
            if(p instanceof King && p.isWhite()==white) king=p;
        }
        if(king==null) return true;

        for(int r=0;r<8;r++) for(int c=0;c<8;c++){
            Piece p = b.getPiece(r,c);
            if(p!=null && p.isWhite()!=white){
                if(p instanceof Pawn){
                    int dir = p.isWhite() ? -1 : 1;
                    if((king.getRow()==r+dir) && (king.getCol()==c+1 || king.getCol()==c-1)) return true;
                } else {
                    if(p.isValidMove(king.getRow(),king.getCol(),b)) return true;
                }
            }
        }
        return false;
    }

    private boolean hasAnyValidMoves(boolean white){
        for(int r=0;r<8;r++) for(int c=0;c<8;c++){
            Piece p = board.getPiece(r,c);
            if(p!=null && p.isWhite()==white){
                for(int tr=0;tr<8;tr++) for(int tc=0;tc<8;tc++){
                    if(p.isValidMove(tr,tc,board)){
                        Board temp = board.copy();
                        temp.movePiece(r,c,tr,tc);
                        if(!isInCheck(temp,white)) return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isWhiteTurn(){ return whiteTurn; }
    public boolean isGameOver(){ return gameOver; }

    public Piece getKingInCheck(){
        for(int r=0;r<8;r++) for(int c=0;c<8;c++){
            Piece p = board.getPiece(r,c);
            if(p instanceof King && isInCheck(board,p.isWhite())) return p;
        }
        return null;
    }

    public boolean canAnyMove(boolean white){ return hasAnyValidMoves(white); }

    
}
package chess;

public class Board {
    private Tile[][] board = new Tile[8][8];

    public Board() {
        loadBoard();
    }

    private void loadBoard() {
        // Empty tiles
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++)
                board[r][c] = new Tile(null);

        // Pawns
        for (int c = 0; c < 8; c++) {
            board[1][c].setPiece(new Pawn(false, 1, c));
            board[6][c].setPiece(new Pawn(true, 6, c));
        }

        // Rooks
        board[0][0].setPiece(new Rook(false, 0, 0));
        board[0][7].setPiece(new Rook(false, 0, 7));
        board[7][0].setPiece(new Rook(true, 7, 0));
        board[7][7].setPiece(new Rook(true, 7, 7));

        // Knights
        board[0][1].setPiece(new Knight(false, 0, 1));
        board[0][6].setPiece(new Knight(false, 0, 6));
        board[7][1].setPiece(new Knight(true, 7, 1));
        board[7][6].setPiece(new Knight(true, 7, 6));

        // Bishops
        board[0][2].setPiece(new Bishop(false, 0, 2));
        board[0][5].setPiece(new Bishop(false, 0, 5));
        board[7][2].setPiece(new Bishop(true, 7, 2));
        board[7][5].setPiece(new Bishop(true, 7, 5));

        // Queens
        board[0][3].setPiece(new Queen(false, 0, 3));
        board[7][3].setPiece(new Queen(true, 7, 3));

        // Kings
        board[0][4].setPiece(new King(false, 0, 4));
        board[7][4].setPiece(new King(true, 7, 4));
    }

    public Piece getPiece(int r, int c) {
        return board[r][c].getPiece();
    }

    public boolean isEmpty(int r, int c) {
        return board[r][c].isEmpty();
    }

    public void movePiece(int sr, int sc, int er, int ec) {
        Piece p = getPiece(sr, sc);
        board[er][ec].setPiece(p);
        board[sr][sc].setPiece(null);
        p.moveTo(er, ec);
    }

    public void removePiece(int r, int c) {
        board[r][c].setPiece(null);
    }

    public void setPiece(int r, int c, Piece p) {
        board[r][c].setPiece(p);
    }

    public boolean isPathClear(int sr, int sc, int er, int ec, Piece p) {
        int dr = Integer.compare(er, sr);
        int dc = Integer.compare(ec, sc);

        int r = sr + dr;
        int c = sc + dc;

        while (r != er || c != ec) {
            if (!isEmpty(r, c)) return false;
            r += dr;
            c += dc;
        }

        return getPiece(er, ec) == null || getPiece(er, ec).isWhite() != p.isWhite();
    }

        // --- Deep copy for simulation ---
    public Board copy() {
        Board b = new Board();

        // Clear default pieces loaded in constructor
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++)
                b.board[r][c].setPiece(null);

        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                Piece p = this.getPiece(r, c);
                if (p != null)
                    b.board[r][c].setPiece(p.getPieceCopy());
            }

        return b;
    }
}

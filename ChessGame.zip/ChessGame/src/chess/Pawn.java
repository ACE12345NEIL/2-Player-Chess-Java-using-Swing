package chess;

public class Pawn extends Piece {
    private boolean firstMove = true;
    private boolean justDoubleStepped = false;

    public Pawn(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♙" : "♟");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        int dir = isWhite ? -1 : 1;

        // Single step forward
        if (c == col && r == row + dir && board.isEmpty(r, c)) return true;

        // Double step forward
        if (firstMove && c == col && r == row + 2 * dir &&
                board.isEmpty(row + dir, c) && board.isEmpty(r, c)) return true;

        // Capture
        if (Math.abs(c - col) == 1 && r == row + dir && !board.isEmpty(r, c) && board.getPiece(r, c).isWhite != this.isWhite) return true;

        // En passant (just return true if valid; actual capture in makeMove)
        if (Math.abs(c - col) == 1 && r == row + dir && board.isEmpty(r, c)) {
            Piece adj = board.getPiece(row, c);
            if (adj instanceof Pawn && adj.isWhite != this.isWhite) {
                Pawn p = (Pawn) adj;
                if (p.hasJustDoubleStepped()) return true;
            }
        }

        return false;
    }

    @Override
    public void moveTo(int r, int c) {
        firstMove = false;
        super.moveTo(r, c);
    }

    public boolean hasJustDoubleStepped() { return justDoubleStepped; }
    public void resetEnPassant() { justDoubleStepped = false; }
    public void setDoubleStep(boolean val) { justDoubleStepped = val; }
}
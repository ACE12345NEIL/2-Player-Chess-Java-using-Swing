package chess;

public class Bishop extends Piece {
    public Bishop(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♗" : "♝");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        Piece target = board.getPiece(r, c);
        if (target != null && target.isWhite() == this.isWhite()) return false;

        if (Math.abs(r - row) == Math.abs(c - col)) { // diagonal
            return board.isPathClear(row, col, r, c, this);
        }
        return false;
    }
}
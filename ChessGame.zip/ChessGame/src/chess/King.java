package chess;

public class King extends Piece {
    private boolean hasMoved = false;

    public King(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♔" : "♚");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        Piece target = board.getPiece(r, c);
        if (target != null && target.isWhite() == this.isWhite()) return false;

        int dr = Math.abs(r - row);
        int dc = Math.abs(c - col);

        // Normal one-square move
        if (dr <= 1 && dc <= 1) return true;

        // Castling
        if (!hasMoved && dr == 0 && dc == 2) {
            int rookCol = (c > col) ? 7 : 0;
            Piece rook = board.getPiece(row, rookCol);
            if (rook instanceof Rook && !((Rook) rook).hasMoved()) {
                int step = (c > col) ? 1 : -1;
                for (int x = col + step; x != rookCol; x += step) {
                    if (!board.isEmpty(row, x)) return false;
                }
                return true;
            }
        }

        return false;
    }

    @Override
    public void moveTo(int r, int c) {
        hasMoved = true;
        super.moveTo(r, c);
    }

    public boolean hasMoved() {
        return hasMoved;
    }
}
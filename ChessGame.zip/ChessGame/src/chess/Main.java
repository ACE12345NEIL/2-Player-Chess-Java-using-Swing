package chess;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Make sure Swing GUI is launched on EDT
        SwingUtilities.invokeLater(() -> new ChessGUI());
    }
}
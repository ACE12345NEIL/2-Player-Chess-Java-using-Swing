package chess;

public abstract class Piece {
    protected int row, col;
    protected boolean isWhite;
    private String icon;

    public Piece(boolean isWhite, int row, int col, String icon) {
        this.isWhite = isWhite;
        this.row = row;
        this.col = col;
        this.icon = icon;
    }

    public abstract boolean isValidMove(int r, int c, Board board);

    public void moveTo(int r, int c) {
        this.row = r;
        this.col = c;
    }

    public String getIcon() {
        return icon;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }
    public boolean isWhite() { return isWhite; }

        // --- Return a new instance of the same piece type ---
    public Piece getPieceCopy() {
        if (this instanceof Pawn) return new Pawn(isWhite, row, col);
        if (this instanceof Rook) return new Rook(isWhite, row, col);
        if (this instanceof Knight) return new Knight(isWhite, row, col);
        if (this instanceof Bishop) return new Bishop(isWhite, row, col);
        if (this instanceof Queen) return new Queen(isWhite, row, col);
        if (this instanceof King) return new King(isWhite, row, col);
        return null;
    }
}
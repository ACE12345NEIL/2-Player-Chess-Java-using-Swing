package chess;

public class Queen extends Piece {
    public Queen(boolean isWhite, int r, int c) {
        super(isWhite, r, c, isWhite ? "♕" : "♛");
    }

    @Override
    public boolean isValidMove(int r, int c, Board board) {
        Piece target = board.getPiece(r, c);
        if (target != null && target.isWhite() == this.isWhite()) return false;

        // horizontal, vertical, or diagonal
        if (row == r || col == c || Math.abs(r - row) == Math.abs(c - col)) {
            return board.isPathClear(row, col, r, c, this);
        }
        return false;
    }
}